Fawwaz Ahmed

101257093



npm install express
npm install hbs
npm install sqlite3
npm install express-session
Npm install body-parser
npm install connect-sqlite3
npm rebuild
npm install



node app.js

Visit http://localhost:3000/

YouTube video link https://youtu.be/-JXm3ezhhn4